ANAWAVES — MINIMAL AUDIO ONLY

Five rebuilt racks. Six mapped macros each. Only Minimal Audio VST3 effects.
No Ableton stock audio processors, FabFilter, or stock limiter.
Ableton rack containers and chain mixers are host infrastructure.
Requires the listed Minimal Audio plug-ins and their licenses.
These new files have been structurally checked, but have NOT been reloaded
or rendered in Ableton. Previous audio-test results do not apply.
Use low monitoring levels and level-match manually.

Chimera
Chain: Rift > Morph > Rift
Macros: Drive, Positive, Negative, Morph, Shift, Drive II

Organism
Chain: Morph > Chorus > Morph
Macros: Vowel A, Shift A, Chorus, Depth, Vowel B, Shift B

Phase Parasite
Chain: Chorus > Rift > Chorus
Macros: Drift A, Depth A, Drive, Asymmetry, Drift B, Depth B

Time Fracture
Chain: Cluster > Chorus > Cluster
Macros: Echo A, Feedback A, Spread A, Smear, Echo B, Feedback B

Spectral Civil War
Chain: Morph > Rift > Cluster > Morph
Macros: Morph A, Drive, Echo, Feedback, Morph B, Countershift