AnaWaves — HEXAGONIC FX Rack

Contents: DarkPlucks.adg and Spectral Notes.adg (Instrument Racks); Shadow Creatures.adg (Audio Effect Rack).
DarkPlucks contains the pluck sound-design solution used in Stereo Voices In My Head.

These racks were saved in Ableton Live 12.4.7–12.4.16 on macOS. Live 12.4.x or newer is recommended; other versions and operating systems have not been verified.
DarkPlucks and Spectral Notes contain third-party VST3 instrument states. The required plug-ins and licenses are not included. Some referenced Ableton devices may require Live Suite.
The files are shared as-is. Use them in your own music; please link to the official download page rather than redistributing the rack files or ZIP.

Support is optional: https://whydonate.com/fundraising/support-anawaves
